import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './screens/Home'


import { AuthContext } from './AuthContext';

const Stack = createNativeStackNavigator();
  export default function App({ navigation }) {
  return (
    <AuthContext.Provider>
      <NavigationContainer>
        <Stack.Navigator>
                 <Stack.Screen name="Home" component={Home} />
        </Stack.Navigator>
      </NavigationContainer>
    </AuthContext.Provider>
  );
}